function validateName() {
  const name = document.getElementById('name').value.trim();
  const nameError = document.getElementById('nameError');
  if (name.length < 2) {
    nameError.textContent = 'Name must be at least 2 characters.';
    return false;
  } else {
    nameError.textContent = '';
    return true;
  }
}

function validateEmail() {
  const email = document.getElementById('email').value.trim();
  const emailError = document.getElementById('emailError');
  const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  if (!emailPattern.test(email)) {
    emailError.textContent = 'Please enter a valid email address.';
    return false;
  } else {
    emailError.textContent = '';
    return true;
  }
}

function validateMessage() {
  const message = document.getElementById('message').value.trim();
  const messageError = document.getElementById('messageError');
  if (message.length < 10) {
    messageError.textContent = 'Message must be at least 10 characters.';
    return false;
  } else {
    messageError.textContent = '';
    return true;
  }
}

function handleSubmit(event) {
  event.preventDefault(); // Prevent actual form submission

  const isNameValid = validateName();
  const isEmailValid = validateEmail();
  const isMessageValid = validateMessage();

  const successMessage = document.getElementById('successMessage');

  if (isNameValid && isEmailValid && isMessageValid) {
    successMessage.textContent = 'Your message has been sent successfully!';
    document.getElementById('contactForm').reset();
  } else {
    successMessage.textContent = '';
  }
  return false;
}

function resetForm() {
  document.getElementById('nameError').textContent = '';
  document.getElementById('emailError').textContent = '';
  document.getElementById('messageError').textContent = '';
  document.getElementById('successMessage').textContent = '';
}
