const images = document.querySelectorAll('.gallery-image');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const closeBtn = document.querySelector('.close');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');
const caption = document.getElementById('caption');
const searchBox = document.getElementById('searchBox');

let currentIndex = 0;

function updateLightbox(index) {
    lightboxImg.src = images[index].src;
    caption.textContent = images[index].alt;
    currentIndex = index;
}

images.forEach((img, index) => {
    img.addEventListener('click', () => {
        lightbox.style.display = 'flex';
        updateLightbox(index);
    });
});

closeBtn.addEventListener('click', () => {
    lightbox.style.display = 'none';
});

prevBtn.addEventListener('click', () => {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    updateLightbox(currentIndex);
});

nextBtn.addEventListener('click', () => {
    currentIndex = (currentIndex + 1) % images.length;
    updateLightbox(currentIndex);
});

searchBox.addEventListener('input', () => {
    const searchTerm = searchBox.value.toLowerCase();
    images.forEach(img => {
        const match = img.alt.toLowerCase().includes(searchTerm);
        img.style.display = match ? '' : 'none';
    });
});
